
library(haven)
library(clipr)

ratio <- read_dta("/EDGAR/agriculture_aggregate_output.dta")
em <- read_dta("/EDGAR/emission_output.dta")
load("LTFinv.RData")

# crop
ratio_crop <- ratio$ratio_crop
ratio_crop[is.na(ratio_crop)] <- 1
ratio_crop[ratio$agriculturesector==2] <- 1
ratio_crop <- matrix(rep(ratio_crop,each=1450), ncol=1450, byrow=TRUE)
Yc <- Y * ratio_crop

ratio_crop <- ratio$ratio_crop
ratio_crop[is.na(ratio_crop)] <- 1
ratio_crop[ratio$agriculturesector==2] <- 1
ratio_crop <- matrix(rep(ratio_crop,each=14839), ncol=14839, byrow=TRUE)
Tc <- T * ratio_crop

Yci <- rowSums(Yc)
Tci <- rowSums(Tc)
Xc <- Yci + Tci

Qc <- em$crop_em_42
Xcinv <- 1/Xc
Xchat <- diag(Xcinv)
Ac <- Tc %*% Xchat
gc()
I <- diag(14839)
Lc <- I-Ac
Lc <- solve(Lc)

Lcy <- Lc %*% Yci
Ycij <- sapply(seq(1,1135,by=6), function(i) rowSums(Yc[,i:(i+5)]))
Lcy <- Lc %*% Ycij
gc()

ec <- Qc/Xc
EBc <- diag(ec) %*% Lcy
EBSc <- colSums(EBc)
write_clip(EBSc)

yindex <- read.csv("y_index.csv")
for (i in 1:14839) {
  j <- yindex$index[i]
  k <- yindex$y_index[i]
  EBc[j,k] <- 0
}
EBKc <- rowSums(EBc)
write_clip(EBKc)
EBic <- colSums(EBc)
write_clip(EBic)


# livestock
ratio_livestock <- ratio$ratio_livestock
ratio_livestock[is.na(ratio_livestock)] <- 1
ratio_livestock[ratio$agriculturesector==1] <- 1
ratio_livestock <- matrix(rep(ratio_livestock,each=1450), ncol=1450, byrow=TRUE)
Yl <- Y * ratio_livestock

ratio_livestock <- ratio$ratio_livestock
ratio_livestock[is.na(ratio_livestock)] <- 1
ratio_livestock[ratio$agriculturesector==1] <- 1
ratio_livestock <- matrix(rep(ratio_livestock,each=14839), ncol=14839, byrow=TRUE)
Tl <- T * ratio_livestock

Yli <- rowSums(Yl)
Tli <- rowSums(Tl)
Xl <- Yli + Tli

Ql <- em$livestock_em_42
Xlinv <- 1/Xl
Xlhat <- diag(Xlinv)
Al <- Tl %*% Xlhat
I <- diag(14839)
Ll <- (I-Al)
Ll <- solve(Ll)

Lly <- Ll %*% Yli
Ylij <- sapply(seq(1,1135,by=6), function(i) rowSums(Yl[,i:(i+5)]))
Lly <- Ll %*% Ylij
gc()

el <- Ql/Xl
EBl <- diag(el) %*% Lly
EBSl <- colSums(EBl)
write_clip(EBSl)

yindex <- read.csv("y_index.csv")
for (i in 1:14839) {
  j <- yindex$index[i]
  k <- yindex$y_index[i]
  EBl[j,k] <- 0
}
EBKl <- rowSums(EBl)
write_clip(EBKl)
EBil <- colSums(EBl)
write_clip(EBil)
