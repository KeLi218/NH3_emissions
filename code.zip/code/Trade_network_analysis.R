
library(R.matlab)
library(reshape2)
library(igraph)
library(foreign)
library(clipr)
library(data.table)
library(RColorBrewer)
library(scales)
library(haven)

# decompose mortality
e <- read.csv("fl.csv",header=FALSE)
e <- as.matrix(e)
e[114,] <- e[114,]+e[149,]
e[,114] <- e[,114]+e[,149]
e <- e[-c(4,99,112,128,145,157,175,190,149),]
e <- e[,-c(4,99,112,128,145,157,175,190,149)]

d <- read_dta("mortality.dta")
dn <- d$new_d
esum <- rowSums(e)
sd_e <- e/esum
sd_e[is.nan(sd_e)] <- 0
dn_e <- sd_e*dn
dn_e_dummy <- dn_e>=1
sum(dn_e_dummy>0)

colnames(dn_e) <- d$countrya3
g1 <- graph_from_adjacency_matrix(dn_e,weighted=TRUE)
g2 <- graph_from_adjacency_matrix(dn_e_dummy)

# network indicators
deg <- degree(g2)
indeg <- degree(g2,mode="in")
outdeg <- degree(g2,mode="out")
stg <- strength(g1)
instg <- strength(g1,mode="in")
outstg <- strength(g1,mode="out")
btw <- betweenness(g1,directed=TRUE,weights=1/E(g1)$weight)
bt <- betweenness(g2,directed=TRUE)
egn <- eigen_centrality(g1,directed=TRUE)[["vector"]]
pge <- page_rank(g1)$vector
cln <- closeness(g1, mode="all",weights=1/E(g1)$weight)
indc <- data.frame(deg,indeg,outdeg,stg,instg,outstg,btw,bt,egn,pge,cln)
write_clip(indc)

# community partition
g <- as.undirected(g1, edge.attr.comb = "sum")
wtc <- cluster_fast_greedy(g)

nameList = c("CHN","IND","USA","RUS","DEU","PAK","BGD","UKR","JPN","POL","VNM","ITA","ROU","FRA","PRK",
             "AUT","JPN","HKG","CZE","ARE","KOR","EGY","GBR","KWT","ITA","CAN","IRN","ESP","SAU","NLD",
             "ZAF","NPL","NGA","DZA","AFG","BRA","AUS","ARG","COL")
V(g)$label.color="black"
country <- read.csv("country_list.csv")
V(g)$label <- as.character(country$abbv)
labelsG = V(g)$label
labelsG[!(labelsG %in% nameList)] = NA

edge.weights <- function(community, network, weight.within = 2200, weight.between = 350) {
  bridges <- crossing(communities = community, graph = network)
  weights <- ifelse(test = bridges, yes = weight.between, no = weight.within)
  return(weights) 
}
c = E(g)$weight 
E(g)$weight <- edge.weights(wtc,g)
layout=layout.fruchterman.reingold(g,weights=E(g)$weight)
E(g)$weight = c

# scale node size
stg <- strength(g)
stg[rev(order(stg))[1:10]] <- stg[rev(order(stg))[1:10]]/2
stg[39] <- stg[39]/2

V(g)$label.cex = stg/10000+0.4
vstg <- (stg/1000)^1.2+5
vstg[(labelsG %in% nameList)] <- vstg[(labelsG %in% nameList)]+5
vstg[39] <- vstg[39]-1
plot(wtc,g, layout=layout, vertex.size=vstg,edge.width=log(E(g)$weight/200+1), edge.color="brown", edge.arrow.size=0.01, vertex.label=labelsG, vertex.label.cex=0.8, 
     vertex.frame.color="gray10",palette=brewer.pal(n=3, name = "RdYlBu"),mark.groups=by(seq_along(wtc$membership), wtc$membership, invisible),edge.curved=0.1
     ,mark.col=alpha(c(brewer.pal(n=3, name = "RdYlBu")),0.3),mark.border=alpha(c(brewer.pal(n=3, name = "RdYlBu")),0.8))


#community circles
library("circlize")

df0 <- read.csv("flow.csv", stringsAsFactors=FALSE)
df1 <- read.csv("plot.csv", stringsAsFactors=FALSE)

circos.clear()
circos.par(start.degree = 90, gap.degree = 4, track.margin = c(-0.1, 0.1), points.overflow.warning = FALSE)
par(mar = rep(0, 4))


chordDiagram(x = df0, grid.col = df1$col, transparency = 0.15,
             order = df1$region, directional = 1,
             direction.type = c("arrows", "diffHeight"), diffHeight  = -0.01,
             annotationTrack = "grid", annotationTrackHeight = c(0.05, 0.1),
             link.arr.type = "big.arrow",link.arr.length = 0.05, link.sort = TRUE, link.largest.ontop = TRUE)

circos.trackPlotRegion(
  track.index = 1, 
  bg.border = NA, 
  panel.fun = function(x, y) {
    xlim = get.cell.meta.data("xlim")
    sector.index = get.cell.meta.data("sector.index")
    reg1 = df1$region[df1$region == sector.index]
    reg2 = df1$reg1[df1$region == sector.index]
    # reg2 = df1$reg1[df1$region == sector.index]
    circos.text(x = mean(xlim), y = 4, 
                labels = reg1, facing = "inside", cex = 1.1, font=2, niceFacing=TRUE)
    circos.text(x = mean(xlim), y = 3, 
                labels = reg2, facing = "outside", cex = 0.9, niceFacing=TRUE)
    circos.axis(labels.cex=0.7, direction = "outside", major.at=seq(from=0,to=64000,by=4000),
                minor.ticks=1, labels.away.percentage = 0.15, major.tick.percentage = 0.5)
  }
)
