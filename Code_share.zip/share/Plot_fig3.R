
# environemt: R 3.5.1

library(igraph)
library(foreign)
library(RColorBrewer)
library(scales)


#------------graph for community partition------------
load("health_effect_community.RData")

nameList = c("CHN","IND","USA","RUS","DEU","PAK","BGD","UKR","JPN","POL","VNM","ITA","ROU","FRA","PRK",
             "AUT","JPN","HKG","CZE","ARE","KOR","EGY","GBR","KWT","ITA","CAN","IRN","ESP","SAU","NLD",
             "ZAF","NPL","NGA","DZA","AFG","BRA","AUS","ARG","COL")
V(g)$label.color="black"
country <- read.csv("country_list.csv")
V(g)$label <- as.character(country$abbv)
labelsG = V(g)$label
labelsG[!(labelsG %in% nameList)] = NA


edge.weights <- function(community, network, weight.within = 2200, weight.between = 350) {
  bridges <- crossing(communities = community, graph = network)
  weights <- ifelse(test = bridges, yes = weight.between, no = weight.within)
  return(weights) 
}
c = E(g)$weight 
E(g)$weight <- edge.weights(wtc,g)
layout=layout.fruchterman.reingold(g,weights=E(g)$weight)
E(g)$weight = c

# scale node size
stg <- strength(g)
stg[rev(order(stg))[1:10]] <- stg[rev(order(stg))[1:10]]/2
stg[39] <- stg[39]/2

V(g)$label.cex = stg/10000+0.4
vstg <- (stg/1000)^1.2+3
vstg[(labelsG %in% nameList)] <- vstg[(labelsG %in% nameList)]+3
stg[39] <- stg[39]-1
plot(wtc,g, layout=layout, vertex.size=vstg,edge.width=log(E(g)$weight/100+1), edge.color="brown", edge.arrow.size=0.01, vertex.label=labelsG, vertex_label_cex=0.5, 
     vertex.frame.color="gray10",palette=brewer.pal(n=3, name = "RdYlBu"),mark.groups=by(seq_along(wtc$membership), wtc$membership, invisible),edge.curved=0.1
     ,mark.col=alpha(c(brewer.pal(n=3, name = "Set2")),0.2),mark.border=alpha(c(brewer.pal(n=3, name = "Set2")),0.8))


#------------graph for community circles------------
library("circlize")

df0 <- read.csv("flow.csv", stringsAsFactors=FALSE)
df1 <- read.csv("plot.csv", stringsAsFactors=FALSE)

circos.clear()
circos.par(start.degree = 90, gap.degree = 4, track.margin = c(-0.1, 0.1), points.overflow.warning = FALSE)
par(mar = rep(0, 4))


chordDiagram(x = df0, grid.col = df1$col, transparency = 0.15,
             order = df1$region, directional = 1,
             direction.type = c("arrows", "diffHeight"), diffHeight  = -0.01,
             annotationTrack = "grid", annotationTrackHeight = c(0.05, 0.1),
             link.arr.type = "big.arrow",link.arr.length = 0.05, link.sort = TRUE, link.largest.ontop = TRUE)

circos.trackPlotRegion(
  track.index = 1, 
  bg.border = NA, 
  panel.fun = function(x, y) {
    xlim = get.cell.meta.data("xlim")
    sector.index = get.cell.meta.data("sector.index")
    reg1 = df1$region[df1$region == sector.index]
    reg2 = df1$reg1[df1$region == sector.index]
    # reg2 = df1$reg1[df1$region == sector.index]
    circos.text(x = mean(xlim), y = 4, 
                labels = reg1, facing = "inside", cex = 1.1, font=2, niceFacing=TRUE)
    circos.text(x = mean(xlim), y = 3, 
                labels = reg2, facing = "outside", cex = 0.9, niceFacing=TRUE)
    circos.axis(labels.cex=0.7, direction = "outside", major.at=seq(from=0,to=48000,by=4000),
                minor.ticks=1, labels.away.percentage = 0.15, major.tick.percentage = 0.5)
  }
)
