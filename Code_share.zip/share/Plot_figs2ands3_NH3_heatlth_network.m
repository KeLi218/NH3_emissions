
% environment: Matlab 2018a

%% degree distribution

load "health_network.mat"
q=dtransfer;
% 1 96.6, 0.5 97.9, 0.1 99.4
% a=q>=0.5;
a=q>=1;
a(181,:)=0;
[~,indeg,outdeg] = degrees(a);

bins=30;
[n,edges] = histcounts(indeg,bins);
y_indeg=[edges(2:bins+1)' n'/181];
y_reg=[log(y_indeg(:,2)),log(y_indeg(:,1))];
[m,~]=find(y_reg==-Inf);
y_reg(m,:)=[];
[b,~,~,~,STATS1]=regress(y_reg(:,1),[y_reg(:,2) ones(length(y_reg),1)]);
x=linspace(0,153);
y=exp(b(2))*x.^(b(1));
b1=b;
scatter(y_indeg(:,1),y_indeg(:,2),'r','o','filled');
axis([0 160 0 0.2])
hold on;
plot(x,y,'r','LineWidth',2);
[n,edges] = histcounts(outdeg,bins);
y_outdeg=[edges(2:bins+1)' n'/181];
y_reg=[log(y_outdeg(:,2)),log(y_outdeg(:,1))];
[m,~]=find(y_reg==-Inf);
y_reg(m,:)=[];
[b,~,~,~,STATS]=regress(y_reg(:,1),[y_reg(:,2) ones(length(y_reg),1)]);
x=linspace(0,153);
y=exp(b(2))*x.^(b(1));
scatter(y_outdeg(:,1),y_outdeg(:,2),'b','+');
axis([0 160 0 0.2])
hold on;
plot(x,y,'b--','LineWidth',2);
legend('P(k_{in})','P(k_{in})=2.136\times k_{in}^{-1.308}','P(k_{out})','P(k_{out})=1.026\times k_{out}^{-1.272}')
legend('boxoff')


%% network indicators

C = readtable("NetworkInd.xlsx",'Sheet','sheet1'); % inter_trade

color1=zeros(181,3);
color1(C.fc==color_group(1,1),:)=repmat(color_group(1,2:4),length(find(C.fc==color_group(1,1))),1);
color1(C.fc==color_group(2,1),:)=repmat(color_group(2,2:4),length(find(C.fc==color_group(2,1))),1);
color1(C.fc==color_group(3,1),:)=repmat(color_group(3,2:4),length(find(C.fc==color_group(3,1))),1);


% outdegree
[~, m]=maxk([C.outdeg C.outstg],12);
m=unique(m(:),'rows');
outdegl=C.outdeg(m);
outdegl_s=C.outstg(m);
countryl=C.abbv(m);
mcolor=color1(m,:);
h=gscatter(C.outstg,C.outdeg,C.fc,color_group(:,2:4),'s*xo^d',6);
set(h(1),'Color',color_group(1,2:4),'MarkerFaceColor',color_group(1,2:4));
set(h(2),'Color',color_group(2,2:4),'MarkerFaceColor',color_group(2,2:4));
legend('off')
labelpoints(outdegl_s, outdegl, countryl,'S',0.2,1,'FontSize',9,'FontWeight','bold','rotation',20,'Color',mcolor);
xlabel('Export-related health effects')
ylabel('Out-degree')


% indegree
[~, m]=maxk([C.indeg C.instg],10);
m=unique(m(:),'rows');
indegl=C.indeg(m);
indegl_s=C.instg(m);
countryl=C.abbv(m);
mcolor=color1(m,:);
h=gscatter(C.instg,C.indeg,C.fc,color_group(:,2:4),'s*xo^d',6);
set(h(1),'Color',color_group(1,2:4),'MarkerFaceColor',color_group(1,2:4));
set(h(2),'Color',color_group(2,2:4),'MarkerFaceColor',color_group(2,2:4));
set(h(3),'Color',color_group(3,2:4),'MarkerFaceColor',color_group(3,2:4));
legend('off')
labelpoints(indegl_s, indegl, countryl,'S',0.2,1,'FontSize',9,'FontWeight','bold','rotation',20,'Color',mcolor);
xlabel('Import-related health effects')
ylabel('In-degree')


% betweenness centrality
[~, m]=maxk([C.bt C.stg],10);
m=unique(m(:),'rows');
btl=C.bt(m);
degl_s=C.stg(m);
countryl=C.abbv(m);
mcolor=color1(m,:);
h=gscatter(C.stg,C.bt,C.fc,color_group(:,2:4),'s*xo^d',6);
set(h(1),'Color',color_group(1,2:4),'MarkerFaceColor',color_group(1,2:4));
set(h(2),'Color',color_group(2,2:4),'MarkerFaceColor',color_group(2,2:4));
set(h(3),'Color',color_group(3,2:4),'MarkerFaceColor',color_group(3,2:4));
legend('off')
labelpoints(degl_s, btl, countryl,'S',0.2,1,'FontSize',9,'FontWeight','bold','rotation',20,'Color',mcolor);
xlabel('Trade-related health effects')
ylabel('Betweenness centrality')


% weighted betweenness centrality
[~, m]=maxk([C.btw C.stg],10);
m=unique(m(:),'rows');
btwl=C.btw(m);
degl_s=C.stg(m);
countryl=C.abbv(m);
mcolor=color1(m,:);
h=gscatter(C.stg,C.btw,C.fc,color_group(:,2:4),'s*xo^d',6);
set(h(1),'Color',color_group(1,2:4),'MarkerFaceColor',color_group(1,2:4));
set(h(2),'Color',color_group(2,2:4),'MarkerFaceColor',color_group(2,2:4));
set(h(3),'Color',color_group(3,2:4),'MarkerFaceColor',color_group(3,2:4));
legend('off')
labelpoints(degl_s, btwl, countryl,'S',0.2,1,'FontSize',9,'FontWeight','bold','rotation',20,'Color',mcolor);
xlabel('Trade-related health effects')
ylabel('Weighted betweenness centrality')


% eigenvector centrality
[~, m]=maxk([C.egn C.stg],10);
m=unique(m(:),'rows');
egnl=C.egn(m);
degl_s=C.stg(m);
countryl=C.abbv(m);
mcolor=color1(m,:);
h=gscatter(C.stg,C.egn,C.fc,color_group(:,2:4),'s*xo^d',6);
set(h(1),'Color',color_group(1,2:4),'MarkerFaceColor',color_group(1,2:4));
set(h(2),'Color',color_group(2,2:4),'MarkerFaceColor',color_group(2,2:4));
set(h(3),'Color',color_group(3,2:4),'MarkerFaceColor',color_group(3,2:4));
legend('off')
labelpoints(degl_s, egnl, countryl,'S',0.2,1,'FontSize',9,'FontWeight','bold','rotation',20,'Color',mcolor);
xlabel('Trade-related health effects')
ylabel('Eigenvector centrality')



% weighted average of nearest neighbor degree
ave_n_deg=zeros(1,length(q));
[deg,~,~]=degrees(a);
[deg1,~,~]=degrees(q);
for i=1:length(a)
neigh=kneighbors(a,i,1);
if isempty(neigh); ave_n_deg(i)=0; continue; end
for j=1:length(neigh)
ave_n_deg(i)=ave_n_deg(i)+(q(i,neigh(j))+q(neigh(j),i))*deg(neigh(j));
end
ave_n_deg(i)=ave_n_deg(i)/deg1(i);
end
ave_w_deg=zeros(max(deg),1);
for i=(min(deg)+1):max(deg)
    c=find(deg==i);
    ave_w_deg(i,1)=sum(ave_n_deg(c))/length(c);
end

deg_s=(min(deg)+1):1:max(deg);
scatter(deg_s,ave_w_deg,40,'filled')
xlabel('Degree')
ylabel('Weighted average of nearest neighbor degree')
